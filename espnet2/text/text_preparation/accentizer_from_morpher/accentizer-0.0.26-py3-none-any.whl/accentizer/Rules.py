# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .AnVar import AnVar
from .Cases import Cases
from .Variant import Variant
from .Word import Word
from .Russian.Stress import Stress


class Rules:
    @property
    def isms (self):
        return (
        {"швИли", Cases.NONE},  # // -швИли ↓ ф. 0

        {"Изм", Cases.Nom | Cases.Acc},
        {"Изма", Cases.Gen},
        {"Изму", Cases.Dat},
        {"Измом", Cases.Ins},
        {"Изме", Cases.Pre},

        {"Измы", (Cases.Nom | Cases.Acc).MakePlural()},
        {"Измов", Cases.Gen.MakePlural()},
        {"Измам", Cases.Dat.MakePlural()},
        {"Измами", Cases.Ins.MakePlural()},
        {"Измах", Cases.Pre.MakePlural()},

        # // -Ист ↓ мо 1а
        {"Ист", Cases.Nom},
        {"Иста", Cases.Gen | Cases.Acc},
        {"Исту", Cases.Dat},
        {"Истом", Cases.Ins},
        {"Исте", Cases.Pre},

        {"Исты", Cases.Nom.MakePlural()},
        {"Истов", (Cases.Gen | Cases.Acc).MakePlural()},
        {"Истам", Cases.Dat.MakePlural()},
        {"Истами", Cases.Ins.MakePlural()},
        {"Истах", Cases.Pre.MakePlural()}
    )

    def GetMasculineAnimate3B(self, s):
        lowercase = s.ToLowerInvariant()
        return (
            # // -чУк, -щУк, -Юк → ф. 3 в ~ 0(Лещук, Прокипчук, Семенюк)
            {s + "к", Cases.NONE},
            {lowercase + "кА", Cases.Gen | Cases.Acc},
            {lowercase + "кУ", Cases.Dat},
            {lowercase + "кОм", Cases.Ins},
            {lowercase + "кЕ", Cases.Pre},

            {lowercase + "кИ", Cases.Nom.MakePlural()},
            {lowercase + "кОв", (Cases.Gen | Cases.Acc).MakePlural()},
            {lowercase + "кАм", Cases.Dat.MakePlural()},
            {lowercase + "кАми", Cases.Ins.MakePlural()},
            {lowercase + "кАх", Cases.Pre.MakePlural()},
        )

    def GetMasculineAnimateA(self, s):
        return (
            #                 // -Ян ф. 1а ~ 0 (Саркисян, Григорян)
            {s + "", Cases.NONE},
            {s + "а", Cases.Gen | Cases.Acc},
            {s + "у", Cases.Dat},
            {s + "ом", Cases.Ins},
            {s + "е", Cases.Pre},

            {s + "ы", Cases.Nom.MakePlural()},
            {s + "ов", (Cases.Gen | Cases.Acc).MakePlural()},
            {s + "ам", Cases.Dat.MakePlural()},
            {s + "ами", Cases.Ins.MakePlural()},
            {s + "ах", Cases.Pre.MakePlural()},

        )

    def GetSurname(self, vowel):
        return (
            {vowel + "в", Cases.Nom},
            {vowel + "ва", Cases.Gen | Cases.Acc | Cases.Nom},
            {vowel + "ву", Cases.Dat | Cases.Acc},
            {vowel + "вым", Cases.Ins | Cases.Dat.MakePlural()},
            {vowel + "ве", Cases.Pre},
            {vowel + "вой", Cases.Dat | Cases.Gen | Cases.Ins | Cases.Pre},

            {vowel + "вы", Cases.Nom.MakePlural()},
            {vowel + "вых", (Cases.Gen | Cases.Acc | Cases.Pre).MakePlural()},
            {vowel + "выми", Cases.Ins.MakePlural()},

            {vowel + "вич", Cases.Nom},
            {vowel + "вича", Cases.Gen | Cases.Acc},
            {vowel + "вичу", Cases.Dat},
            {vowel + "вичем", Cases.Ins},
            {vowel + "виче", Cases.Pre},
            {vowel + "вичей", Cases.Gen.MakePlural()},

            {vowel + "вна", Cases.Nom},
            {vowel + "вны", Cases.Gen | Cases.Nom.MakePlural()},
            {vowel + "вне", Cases.Dat | Cases.Pre},
            {vowel + "вной", Cases.Ins},
            {vowel + "вною", Cases.Ins},
            {vowel + "вну", Cases.Acc},
        )

    def GetFeminine3A(self, vowel):
        return (
            {vowel + "а", Cases.Nom},
            {vowel + "и", Cases.Gen | Cases.Nom.MakePlural()},
            {vowel + "е", Cases.Dat | Cases.Pre},
            {vowel + "ой", Cases.Ins},
            {vowel + "ою", Cases.Ins},
            {vowel + "у", Cases.Acc},
        )

    @property
    def suffixes (self):
        l1 = "чУ,щУ,Ю".split(',').SelectMany(self.GetMasculineAnimate3B)
        l2 = [x+'е' for x in "АЯОЁЫУЮЭЕ"]
        l3 = ["бЕко","ддИно","тдИно"].SelectMany(self.GetSurname)
        l4 = self.GetMasculineAnimateA("Ян")

        return [*l1, *l2, *l3,*l4 ]

        """
        TODO:
         -Ировать ↓ св-нсв
         -Ирование ↓ с 7а
         -Иция, -Ация ↓ ж 7а
         -ирОвка ↓ с 3*а
         -ирОвщик ↓ мо 3а
        """