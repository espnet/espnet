# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .StressMarkPlacement import StressMarkPlacement


class AnVar:
    """
        Содержит информацию о положении знака ударения и «точек над Ё» в слове.
        PrimaryStressPos: Положение основного ударения (номер ударной буквы):
             0 == слово не несет ударения ("к") или не нуждается в знаке ударения ("скрыть", "осёл");
             1 == как в слове "арка";
             2 == как в слове "кошка" и т.д.
        YoMask: Информация о наличии в слове букв Ё.
    """
    __slots__ = ('PrimaryStressPos', 'YoMask',)

    def __init__(self, primary_stress_pos, yo_mask):
        self.PrimaryStressPos = primary_stress_pos
        self.YoMask = yo_mask

    def is_empty(self):
        return self.PrimaryStressPos == 0 and self.YoMask == 0

    def apply_to(self, token, primary_stress_mark, primary_stress_mark_placement=StressMarkPlacement.AFTER_STRESSED_VOWEL):
        """
        Ставит знак ударения и точки над Ё в данном слове.
        :param token: Слово
        :param primary_stress_mark: Знак ударения
        :param primary_stress_mark_placement: Место постановки ударения (до или после ударной буквы).
        :return: Слово с поставленными знаками.
        """
        stress_pos = self.PrimaryStressPos

        if stress_pos > 0:
            offset = primary_stress_mark_placement
            primary_stress_pos = stress_pos + offset
            token = token[:primary_stress_pos] + primary_stress_mark + token[primary_stress_pos:]

        e = self.YoMask

        if e > 0:
            i = -1
            mask = 1
            while mask < 256:
                i = index_of_any(token, {'е', 'ё', 'Е', 'Ё'}, i + 1)
                if i == -1:
                    break
                c = token[i]

                if (e & mask) != 0 and c != 'ё' and c != 'Ё':
                    _ = token[:i] + ('ё' if c == 'е' else 'Ё')
                    token = _ + token[i+1:]
                mask <<= 1
        return token

    @classmethod
    def StripAndGetAnVar(cls, s, primary_stress_mark):
        """
            :param s:
            :param primary_stress_mark:
            :return: Пара (слово без знаков ударения и точек над Ё, AnVar)
        """
        return cls.Strip(s, primary_stress_mark), cls.GetAnVar(s, primary_stress_mark)

    @staticmethod
    def Strip(s, primary_stress_mark):
        return s.replace(primary_stress_mark, "").replace('ё', 'е').replace('Ё', 'Е')

    @classmethod
    def GetAnVar(cls, accented_word, primary_stress_mark):
        index_of_stress_mark = accented_word.find(primary_stress_mark)
        stress_pos = 0 if index_of_stress_mark == -1 else index_of_stress_mark
        word = accented_word.replace(primary_stress_mark, "")

        e = 0
        i = -1
        mask = 1

        while mask < 256:
            i = index_of_any(word, {'е', 'ё', 'Е', 'Ё'}, i + 1)
            if i == -1:
                break
            c = word[i]
            if c == 'ё' or c == 'Ё':
                e |= mask
            mask <<= 1

        return AnVar(stress_pos, e)


def index_of_any(word_, list_, pos):
    i = pos
    while i < len(word_):
        for e in list_:
            if word_[i] == e:
                return i
        i += 1
    return -1
