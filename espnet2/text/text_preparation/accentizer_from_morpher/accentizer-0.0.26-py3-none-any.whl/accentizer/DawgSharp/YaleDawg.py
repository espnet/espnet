# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

import array
import codecs
from typing import NamedTuple
from ..BinaryReaderExtensions import read_int32, read_array


class YaleDawg:
    payloads: array.array
    nodeCount = rootNodeIndex = 0
    firstChildForNode: array.array
    child_index: array.array
    child_char: array.array

    def __init__(self, reader, read_payload):
        _firstInt = read_int32(reader)  # https://github.com/bzaar/DawgSharp/blob/master/DawgSharp/Dawg.cs #117
        _version = read_int32(reader)  # YaleDawg - версия только вторая (первая инициализирует MatrixDawg)

        self.nodeCount = read_int32(reader)
        self.rootNodeIndex = read_int32(reader)
        self.payloads = read_array(reader, read_payload)
        chars = read_array(reader, read_char)

        self.totalChildCount = read_int32(reader)

        self.firstChildForNode = array.array('i')

        self.child_index = array.array('i')
        self.child_char = array.array('u')

        global_child_i = 0

        for child1_i in range(self.nodeCount):
            self.firstChildForNode.append(global_child_i)

            child_count = self.read_int(reader, len(chars) + 1)

            for child_i in range(child_count):
                char_index = self.read_int(reader, len(chars))
                child_node_index = read_int32(reader)
                self.child_index.append(child_node_index)
                self.child_char.append(chars[char_index])
                global_child_i += 1

        self.firstChildForNode.append(self.totalChildCount)

    @staticmethod
    def read_int(reader, count_of_possible_values):
        return reader.read(2)[0] if count_of_possible_values > 256 else reader.read(1)[0]

    def __getitem__(self, word):
        node_i = self.rootNodeIndex

        for c in word:
            first_child_i = self.firstChildForNode[node_i]
            last_child_i = self.firstChildForNode[node_i + 1]

            child_i = -1
            for i in range(first_child_i, last_child_i):
                if self.child_char[i] == c:
                    child_i = i
                    break
            if child_i < 0:
                return None

            node_i = self.child_index[child_i]

        return self.payloads[node_i] if node_i < len(self.payloads) else None

    def get_longest_prefix(self, word):
        node_i = self.rootNodeIndex

        for c in word:
            first_child_i = self.firstChildForNode[node_i]
            last_child_i = self.firstChildForNode[node_i + 1]

            child_i = -1
            for i in range(first_child_i, last_child_i):
                if self.child_char[i] == c:
                    child_i = i
                    break
            if child_i < 0:
                break

            node_i = self.child_index[child_i]

        return self.payloads[node_i] if node_i < len(self.payloads) else None


def read_char(reader):
    c = codecs.getreader('utf-8')(reader).read(1)
    return c
