# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

