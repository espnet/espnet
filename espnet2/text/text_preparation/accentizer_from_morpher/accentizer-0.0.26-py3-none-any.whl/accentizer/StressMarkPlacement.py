# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

class StressMarkPlacement:
    BEFORE_STRESSED_VOWEL = -1
    AFTER_STRESSED_VOWEL = 0
