# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .Cases import Cases
from .IDictionary import IDictionary
from .Variant import Variant
from .Word import Word


class MultiWordDictionary(IDictionary):
    dictionary: dict
    _max_key_len: int

    def __init__(self, lines, fn_strip=lambda x: x.strip()):
        """
        :param lines: список слов
        :param fn_strip: Функция удаления знаков ударения и точек над Ё.
        """
        self.dictionary = {}
        a = [list(fn_strip(y) for y in line.split(' ')) for line in lines]

        for aa in a:
            aa = tuple(aa)
            key = " ".join([_x[0] for _x in aa])
            variants = tuple(Variant(_x[1], Cases.NONE, False) for _x in aa)
            dz = {key: tuple(Word(variants=[x]) for x in variants)}
            self.dictionary.update(**dz)

        self._max_key_len = 1 if len(self.dictionary) == 0 else max([len(x) for x in a])

    def lookup(self, key):
        k = " ".join(key)
        z = self.dictionary.get(k)
        return z

    def get_max_key_len(self) -> int:
        return self._max_key_len
