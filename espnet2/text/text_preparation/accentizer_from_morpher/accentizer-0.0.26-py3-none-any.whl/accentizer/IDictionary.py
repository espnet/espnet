# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from typing import List
from .Variant import Variant


class IDictionary:  # interface
    """
    Позволяет подключать дополнительные словари.
    """

    def get_max_key_len(self) -> int:
        """ Максимальная длина ключа в словаре (в словах). """
        raise NotImplementedError

    def lookup(self, key: List[str]) -> List[Variant]:
        """
        Ищет в словаре информацию о слове или словосочетании.
        :param key: Слово из текста или несколько стоящих подряд слов
        :return: Информация о слове или None.
        """
        raise NotImplementedError
