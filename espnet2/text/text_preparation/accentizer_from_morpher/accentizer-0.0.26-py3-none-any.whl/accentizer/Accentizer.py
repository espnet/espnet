# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .AnnotatedToken import AnnotatedToken
from .Annotation import Annotation
from .AnVar import AnVar
from .Cases import Cases, make_plural
from .PipeFormatter import PipeFormatter
from .Tokenizer import Tokenizer
from .AccentizerOptions import AccentizerOptions
from .IDictionary import IDictionary
from .Prepositions import _preposition_cases
from .Variant import Variant
from .Word import Word

from typing import List
from typing import Tuple


class Accentizer:
    """
    Основной класс библиотеки, выполняет расстановку ударений в текстах.
    """
    _dictionaries: Tuple[IDictionary]
    _max_key_len: int
    _empty_annotation = None

    def __init__(self, dictionaries: Tuple[IDictionary]):
        """
            :param dictionaries: Передайте сюда load_standard_dictionaries().
        """
        self._dictionaries = dictionaries
        self._max_key_len = max([d.get_max_key_len() for d in dictionaries])

    def accentize(self, text, options=AccentizerOptions()) -> str:
        formatter = PipeFormatter(primary_stress_mark=options.SourceTextStressMark)
        annotated_tokens = self.annotate(text, options)
        formatted_tokens = [formatter.format(token) for token in annotated_tokens]
        result = "".join(formatted_tokens)
        return result

    def annotate(self, text, options=AccentizerOptions()) -> List[AnnotatedToken]:
        tokens = list()
        lowercase_tokens = list()
        separators = list()
        source_an_vars = list()

        token_iterator = self._get_token_iterator(text, options.SourceTextStressMark)

        yield AnnotatedToken(self._empty_annotation, next(token_iterator))  # first separator

        expected_cases = Cases.NONE
        while True:
            while len(tokens) < self._max_key_len:
                try:
                    token = next(token_iterator)
                except StopIteration:
                    break
                (stripped, anvar) = AnVar.StripAndGetAnVar(token, options.SourceTextStressMark)
                tokens.append(stripped)
                lowercase_tokens.append(stripped.lower())
                source_an_vars.append(anvar)
                separators.append(next(token_iterator))
            if len(tokens) == 0:
                break
            words = self._get_words(lowercase_tokens, source_an_vars)
            last_token = None
            current_word_cases = Cases.NONE
            if words:
                for word in words:
                    last_token = tokens.pop(0)
                    lowercase_tokens.pop(0)
                    source_an_vars.pop(0)
                    variants = word.Variants
                    if expected_cases != Cases.NONE and len(variants) > 1:
                        filtered_variants = list(filter(lambda v: (expected_cases & v.Cases), variants))
                        if len(filtered_variants) > 0:
                            variants = filtered_variants
                    if len(variants) > 1:
                        is_surname = options.PreferNames or self._is_capitalized(last_token)
                        caps_variants = list(filter(lambda v: (v.IsName == is_surname), variants))
                        if len(caps_variants) > 0:
                            variants = caps_variants

                    current_word_cases = 0
                    for var in variants:
                        current_word_cases |= var.Cases

                    yield AnnotatedToken(Annotation([v.AnVar for v in variants]), last_token)
                    yield AnnotatedToken(self._empty_annotation, separators.pop(0))
            else:
                last_token = tokens.pop(0)
                yield AnnotatedToken(self._empty_annotation, last_token)
                lowercase_tokens.pop(0)
                source_an_vars.pop(0)
                yield AnnotatedToken(self._empty_annotation, separators.pop(0))

            if last_token is None:
                expected_cases = Cases.NONE
            else:
                try:
                    cases = _preposition_cases[last_token]
                    expected_cases = cases | make_plural(cases)
                except KeyError:
                    expected_cases = current_word_cases

    @staticmethod
    def _get_token_iterator(text, stress_mark):
        if isinstance(text, str):
            return Tokenizer.tokenize(text, stress_mark)
        try:
            return iter(text)
        except TypeError:
            return text

    @staticmethod
    def _is_capitalized(s):
        return len(s) >= 2 and s[0].isupper() and s[1].islower()

    def _get_words(self, lowercase_tokens, source_an_vars):
        len_ = len(lowercase_tokens)
        while len_ > 0:
            key = lowercase_tokens[:len_]
            words = self.lookup(key)
            if words:
                return [self._apply_source_anvars(w, a) for (w, a) in zip(words, source_an_vars)]
            len_ -= 1
        return

    @staticmethod
    def _apply_source_anvars(w, a):
        if a.is_empty():
            return w
        matches = list(filter(lambda v: v.AnVar == a, w.Variants))
        return Word(matches if len(matches) == 1 else (Variant(a, Cases.NONE, False),))

    def lookup(self, key):
        for dictionary in self._dictionaries:
            r = dictionary.lookup(key)
            if r:
                return r

    @staticmethod
    def _contains_stress_mark(key, stress_mark):
        for token in key:
            try:
                if token.index(stress_mark) != -1:
                    return True
            except ValueError:
                return False
        return False

