# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .IDictionary import IDictionary
from .Russian.Syllable import is_multisyllable
from .Variant import Variant
from .Word import Word
from .PayloadExtensions import to_variant


class SuffixDictionary(IDictionary):
    """
    Добавляет ударение, ориентируясь на известные суффиксы.
    Позволяет охватить несловарные слова.
    """

    def __init__(self, dawg):
        self.dawg = dawg

    def lookup(self, key):
        if len(key) == 1:
            lowercase_key = key[0]
            if is_multisyllable(lowercase_key):
                variant = self.try_add_stress(lowercase_key)
                if variant:
                    return Word(variant),

    def try_add_stress(self, lowercase_key) -> Variant:
        payload = self.dawg.get_longest_prefix(lowercase_key[::-1])
        if payload:
            return to_variant(payload, lowercase_key)

    def get_max_key_len(self) -> int:
        return 1
