# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .StressMarkPlacement import StressMarkPlacement
from .AnnotatedToken import AnnotatedToken


class PipeFormatter:
    """
        Форматирует AnnotatedToken,
        разделяя варианты постановки ударения
        вертикальной чертой (|, англ. pipe)
        вот так: за+мок|замо+к.
    """
    Separator = "|"
    PrimaryStressMark = '\u0301'
    PrimaryStressMarkPlacement = StressMarkPlacement.AFTER_STRESSED_VOWEL

    def __init__(self, primary_stress_mark: str):
        self.PrimaryStressMark = primary_stress_mark

    def format(self, annotated_token: AnnotatedToken):

        if not annotated_token.annotation:
            return annotated_token.string

        l = [
            (lambda v: v.apply_to(
                annotated_token.string, self.PrimaryStressMark,
                self.PrimaryStressMarkPlacement
            ),
             annotated_token.annotation.variants), ]

        z = []
        for f, x in l:
            z += list(map(f, x))
        if not z:
            z = [annotated_token.string]
        return f"{self.Separator}".join(z)

