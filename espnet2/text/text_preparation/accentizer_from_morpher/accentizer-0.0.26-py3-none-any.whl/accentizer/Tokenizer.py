# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from unicodedata import category
from typing import List

import unicodeblock.blocks


class Tokenizer:
    @staticmethod
    def tokenize(text: str, stress_mark: str = '\u0301') -> List[str]:
        """
            Разбивает текст на части - токены.
            :return Последовательность токенов.
            Токены бывают двух видов – слова и разделители.
            Первым всегда идет разделитель, даже если он пустой.
            Затем чередуются слова и разделители.
            Таким образом, разделителей всегда на один больше, чем слов.
            Если два рядом стоящих слова принадлежат разным системам письменности
            (например, русское и сразу за ним китайское), то
            между ними вставляется пустой разделитель.
            См. тесты.
        """
        if len(stress_mark) != 1:
            raise NotImplementedError("'stress_mark' должен содержать 1 символ.")

        stress_mark_char = stress_mark[0]

        token_start = 0
        whitespace_type = b"SPACE"
        char_type = whitespace_type

        for i in range(0, len(text)):
            c = text[i]
            if c == stress_mark_char:
                continue
            new_type = unicodeblock.blocks.of(c) if c.isalnum() else whitespace_type
            if new_type == char_type:
                continue
            token = text[token_start: i]
            yield token

            if char_type != whitespace_type and new_type != whitespace_type:
                yield ""
            token_start = i
            char_type = new_type

        end_token = text[token_start:]
        yield end_token

        if char_type != whitespace_type:
            yield ""
