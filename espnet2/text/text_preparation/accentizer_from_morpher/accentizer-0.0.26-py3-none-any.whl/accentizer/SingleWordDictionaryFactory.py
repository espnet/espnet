# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .SingleWordDictionary import SingleWordDictionary
from .DawgSharp.YaleDawg import YaleDawg
from .PayloadExtensions import read_payload


class SingleWordDictionaryFactory:
    @classmethod
    def LoadSingleWordDictionary(cls, singleVariant, multiVariant):
        return SingleWordDictionary(
            YaleDawg(singleVariant, read_payload),
            YaleDawg(multiVariant, read_payloads)
        )


def read_payloads(r):
    n = r.read(1)[0]
    arr = []
    i = 0
    while i < n:
        arr.append(read_payload(r))
        i += 1
    return arr
