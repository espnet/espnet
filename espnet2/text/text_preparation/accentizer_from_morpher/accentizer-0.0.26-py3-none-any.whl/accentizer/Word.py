# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

class Word:
    __slots__ = ('Variants',)

    def __init__(self, variants):
        self.Variants = variants if hasattr(variants, '__iter__') else [variants]
