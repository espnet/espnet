# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .AnVar import AnVar
from .Variant import Variant

import struct


def to_variant(p, key) -> Variant:
    return Variant(_get_an_var(p, len(key)), _get_cases(p), _is_name(p))


def _get_an_var(u, key_len):
    return AnVar(
        # Ударение считается с конца слова. Это уменьшает размер словаря на 20%.
        primary_stress_pos=0 if (u & 0xFF) == 0 else key_len + 1 - (u & 0xFF),
        yo_mask=(u >> 8) & 0xFF)


def _is_name(p):
    return (p & 0x1000_0000) != 0


def _get_cases(p):
    return (p >> 16) & 0xFFF


def read_payload(r):
    i_32 = struct.unpack('<i', r.read(4))[0]
    return i_32
