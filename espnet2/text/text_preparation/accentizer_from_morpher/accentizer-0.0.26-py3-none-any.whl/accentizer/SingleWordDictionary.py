# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .IDictionary import IDictionary
from .Word import Word
from .PayloadExtensions import to_variant

from typing import List


class SingleWordDictionary(IDictionary):
    single_variant_dawg = None
    multi_variant_dawg = None

    def __init__(self, single_variant_dawg,  multi_variant_dawg):
        self.single_variant_dawg = single_variant_dawg
        self.multi_variant_dawg = multi_variant_dawg

    def get_max_key_len(self) -> int:
        return 1

    def lookup(self, key: List[str]) -> List[Word]:
        if len(key) == 1:
            result = self._lookup(key[0])
            if result is not None:
                return [result]

    def _lookup(self, key: str) -> Word:
        fv = self._find_variants(key)
        if fv:
            return Word([to_variant(v, key) for v in fv])

    def _find_variants(self, key: str):
        payload = self.single_variant_dawg[key]
        if payload:
            return [payload]
        return self.multi_variant_dawg[key]
