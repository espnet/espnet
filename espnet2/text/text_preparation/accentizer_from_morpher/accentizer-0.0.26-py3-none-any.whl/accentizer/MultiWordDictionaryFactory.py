# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from io import BytesIO
import zlib

from .AnVar import AnVar
from .MultiWordDictionary import MultiWordDictionary
from .BinaryReaderExtensions import read_array, read_int32


def inflate(data):
    decompress = zlib.decompressobj(
            -zlib.MAX_WBITS
    )
    inflated = decompress.decompress(data)
    inflated += decompress.flush()
    return inflated


class MultiWordDictionaryFactory:
    primaryStressMark = "/"

    @classmethod
    def load_multi_word_dictionary(cls, byte_array):
        return MultiWordDictionary(_deserialize_blocks(byte_array),
                                   lambda s: AnVar.StripAndGetAnVar(s, cls.primaryStressMark))


def _deserialize_blocks(byte_array):
    reader = BytesIO(byte_array)
    offsets = read_array(reader, read_int32)

    def get_block_lines(offset, i):
        length = (offset - len(byte_array) if i == len(offsets) - 1 else (offsets[i + 1] - offset))
        stream = BytesIO(byte_array)
        stream.seek(offset)
        block = inflate(stream.read(length)).decode('utf-8').split('\r\n')
        return block

    lists = [get_block_lines(offset, offsets.index(offset)) for offset in offsets]

    def flatten(t):
        return [item for sublist in t for item in sublist]

    return flatten(lists)

