# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from typing import NamedTuple
from .Annotation import Annotation


class AnnotatedToken(NamedTuple):
    """
        Содержит токен и информацию об ударении в нем.

        Attributes:
            annotation  Информация об ударении и точках над Ё.
                        Может быть None.
            string      Строковое представление токена.
    """
    annotation: Annotation
    string: str
