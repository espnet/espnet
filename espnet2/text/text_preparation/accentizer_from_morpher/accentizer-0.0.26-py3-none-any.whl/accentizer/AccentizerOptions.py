# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

class AccentizerOptions:
    # Знак ударения, используемый в исходном тексте.
    # Вообще говоря, не обязан совпадать со знаком на выходе.
    SourceTextStressMark = '\u0301'

    # Отдавать предпочтение именам / фамилиям в неоднозначных случаях типа
    # Во́лков | Волко́в,
    # МИ́ЛА | МИЛА́.
    PreferNames = False
