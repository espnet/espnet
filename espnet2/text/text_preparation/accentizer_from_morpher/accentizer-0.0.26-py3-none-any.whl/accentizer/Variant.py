# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

class Variant:
    """
        Содержит информацию о слове:
        информацию об ударении (AnVar),
        в каком оно может быть падеже,
        является ли именем/фамилией.
    """

    def __init__(self, AnVar, Cases, IsName):
        self.AnVar = AnVar
        self.Cases = Cases
        self.IsName = IsName
