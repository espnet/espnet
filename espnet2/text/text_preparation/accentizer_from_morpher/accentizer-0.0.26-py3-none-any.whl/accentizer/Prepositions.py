# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .Cases import Cases

_preposition_cases = {
    "без": Cases.Gen,
    "благодаря": Cases.Dat,
    "в": Cases.Acc | Cases.Pre,
    "вблизи": Cases.Gen,
    "ввиду": Cases.Gen,
    "вглубь": Cases.Gen,
    "вдоль": Cases.Gen,
    "вместо": Cases.Gen,
    "во": Cases.Acc | Cases.Pre,
    "внутри": Cases.Gen,
    "вокруг": Cases.Gen,
    "впереди": Cases.Gen,
    "вроде": Cases.Gen,
    "вслед": Cases.Dat,
    "вследствие": Cases.Gen,
    "для": Cases.Gen,
    "до": Cases.Gen,
    "за": Cases.Acc | Cases.Ins,
    "из": Cases.Gen,
    "из-за": Cases.Gen,  # TODO: предлоги с дефисом сейчас разбиваются на слова
    "из-под": Cases.Gen,
    "к": Cases.Dat,
    "ко": Cases.Dat,
    "между": Cases.Gen | Cases.Ins,
    "на": Cases.Acc | Cases.Pre,
    "над": Cases.Ins,
    # {"надо": Case.Ins}, # омоним
    "навстречу": Cases.Dat,
    "наподобие": Cases.Gen,
    "насчет": Cases.Gen,
    "насчёт": Cases.Gen,
    "о": Cases.Acc | Cases.Pre,
    "об": Cases.Pre,
    "около": Cases.Gen,
    "от": Cases.Gen,
    "перед": Cases.Ins,
    "передо": Cases.Ins,
    "поперек": Cases.Gen,
    "поперёк": Cases.Gen,
    "по": Cases.Dat | Cases.Acc | Cases.Pre,
    "под": Cases.Acc | Cases.Ins,
    "подо": Cases.Ins,
    "после": Cases.Gen,
    "посредством": Cases.Gen,
    "при": Cases.Pre,
    "с": Cases.Gen | Cases.Acc | Cases.Ins,
    "сквозь": Cases.Acc,
    "со": Cases.Gen | Cases.Acc | Cases.Ins,
    "у": Cases.Gen,
    "через": Cases.Acc,  # TODO добавить еще предлоги

    # Не совсем предлоги, но принцип тот же...
    "два": Cases.Gen,
    "оба": Cases.Gen,
    "обе": Cases.Gen,
    "две": Cases.Gen,
    "три": Cases.Gen,
    "четыре": Cases.Gen
}
