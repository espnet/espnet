# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

class Cases:
    """
    Битовая маска - набор падежей.
    """
    NONE = 0
    Nom = 1  # Именительный
    Gen = 2  # Родительный
    Dat = 4  # Дательный
    Acc = 8  # Винительный
    Ins = 16  # Творительный
    Pre = 32  # Предложный


def make_plural(cases):
    return cases << 8
