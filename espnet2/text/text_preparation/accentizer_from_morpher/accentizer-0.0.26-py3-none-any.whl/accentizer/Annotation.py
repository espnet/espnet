# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from typing import List

from .Variant import Variant


class Annotation:
    """
        Информация о постановке ударения в слове.
        Variants - Варианты постановки ударения в слове.
    """
    variants: List[Variant]

    def __init__(self, v: List[Variant]):
        self.variants = v
