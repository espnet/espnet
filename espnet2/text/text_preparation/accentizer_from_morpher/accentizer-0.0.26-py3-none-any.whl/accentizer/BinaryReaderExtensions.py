# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

import struct


def read_array(reader, read):
    def ReadSequence(reader, read):
        yield read(reader)
    n = read_int32(reader)
    _r = []
    for x in range(n):
        _r += list(ReadSequence(reader, read))
    return _r


def read_int32(reader):
    return struct.unpack('<i', reader.read(4))[0]
