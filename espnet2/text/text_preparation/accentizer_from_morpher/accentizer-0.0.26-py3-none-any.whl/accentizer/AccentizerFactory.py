# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python


from .Accentizer import Accentizer
from .DawgSharp.YaleDawg import YaleDawg
from .MultiWordDictionaryFactory import MultiWordDictionaryFactory
from .PayloadExtensions import read_payload
from .SingleWordDictionaryFactory import SingleWordDictionaryFactory
from .IDictionary import IDictionary
from .SuffixDictionary import SuffixDictionary

from typing import Tuple
import os


class AccentizerFactory:
    """
        Первый раз пользуетесь библиотекой? Вам сюда.
        Используйте этот статический класс, чтобы создать объект Accentizer.
    """

    @classmethod
    def create_standard_accentizer(cls) -> Accentizer:
        """
            Создает Accentizer со стандартным набором словарей,
            загружаемых из ресурсов библиотеки.
        """
        return Accentizer(cls.load_standard_dictionaries())

    @classmethod
    def create_standard_accentizer_with_exception_dictionary(cls, exception_dictionary: IDictionary) -> Accentizer:
        """ Пример, как можно добавить словарь исключений. """
        user_dicts = exception_dictionary,
        return Accentizer(user_dicts + cls.load_standard_dictionaries())

    @classmethod
    def load_standard_dictionaries(cls) -> Tuple[IDictionary]:
        return cls._combine_standard_dictionaries(cls.load_single_word_dictionary(), cls.load_multi_word_dictionary())

    @staticmethod
    def _combine_standard_dictionaries(load_single_word_dictionary,
                                       load_multi_word_dictionary) -> Tuple[IDictionary]:
        return (
            load_single_word_dictionary,
            load_multi_word_dictionary,
            _load_suffix_dictionary()
        )

    @classmethod
    def load_single_word_dictionary(cls) -> IDictionary:
        with _open_bin('SingleWordSingleVariantDictionary.bin') as single:
            with _open_bin('SingleWordMultiVariantDictionary.bin') as multi:
                return SingleWordDictionaryFactory.LoadSingleWordDictionary(single, multi)

    @classmethod
    def load_multi_word_dictionary(cls) -> IDictionary:
        with _open_bin('MultiWordDictionary.bin') as f:
            return MultiWordDictionaryFactory.load_multi_word_dictionary(f.read())


def _load_suffix_dictionary():
    with _open_bin('SuffixDictionary.bin') as f:
        return SuffixDictionary(YaleDawg(f, read_payload))


def _open_bin(name):
    return open(os.path.join(os.path.dirname(__file__), name), 'rb')


def load_standard_dictionaries():
    return AccentizerFactory.load_standard_dictionaries()
