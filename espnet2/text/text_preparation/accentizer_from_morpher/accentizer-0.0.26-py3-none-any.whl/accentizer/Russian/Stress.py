# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

import re


class Stress:
    PrimaryStressMark = "\u0301"

    SecondaryStressMark = "\u0300"

    @staticmethod
    def StripStressMarksAndYo(s: str):
        stripped = Stress.StripStressMarks(s).replace('ё', 'е')
        return stripped

    @staticmethod
    def StripStressMarks (s: str):
        return s.replace(Stress.PrimaryStressMark, "")

    @staticmethod
    def ConvertUpperCaseToStressMark(s: str):
        return re.sub("([АЯОЁИЫУЮЭЕ])", lambda match: match.groups[0].lower() + Stress.PrimaryStressMark, s)

    @staticmethod
    def convert_stress_mark_to_upper_case(s: str):
        return re.sub("([аяоёиыуюэе])" + Stress.PrimaryStressMark, lambda match: match.groups[1].upper(), s)  # error