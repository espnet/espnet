# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

class Vowels:
    lowercase_string = "аяоёиыуюэе"
    uppercase_string = "АЯОЁИЫУЮЭЕ"
