# Copyright (c) 2021 Sergey Slepov, https://morpher.ru/accentizer/python

from .Vowels import Vowels


def is_multisyllable(lowercase_russian_word):
    vowels = Vowels.lowercase_string
    return index_of_any(lowercase_russian_word, vowels) != last_index_of_any(lowercase_russian_word, vowels)


def index_of_any(s, anyof):
    for i,c in enumerate(s):
        if anyof.find(c) != -1:
            return i
    return -1


def last_index_of_any(s, anyof):
    for i,c in enumerate(s[::-1]):
        if anyof.find(c) != -1:
            return len(s) - i - 1
    return -1
